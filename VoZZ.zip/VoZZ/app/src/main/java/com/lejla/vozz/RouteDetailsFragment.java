package com.lejla.vozz;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class RouteDetailsFragment extends Fragment {

    private SharedPreferences sharedPreferences;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_route_details, container, false);

        sharedPreferences = requireActivity().getSharedPreferences("RoutesPrefs", Context.MODE_PRIVATE);

        TextView startDestTextView = view.findViewById(R.id.start_dest);
        TextView endDestTextView = view.findViewById(R.id.end_dest);
        TextView startTextView = view.findViewById(R.id.start);
        TextView endTextView = view.findViewById(R.id.end);

        String start = sharedPreferences.getString("start", "");
        String end = sharedPreferences.getString("end", "");

        startDestTextView.setText(start);
        endDestTextView.setText(end);
        startTextView.setText(start);
        endTextView.setText(end);

        TextView pricingTextView = view.findViewById(R.id.pricing);

        // Generate the integer value
        String pricingText = 30 + " BAM";
        pricingTextView.setText(pricingText);

        return view;
    }
}