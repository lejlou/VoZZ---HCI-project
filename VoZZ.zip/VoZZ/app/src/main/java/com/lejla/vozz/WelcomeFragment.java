package com.lejla.vozz;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.NavDirections;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class WelcomeFragment extends Fragment {

    private EditText cardIdEditText;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_welcome, container, false);

        cardIdEditText = view.findViewById(R.id.card_id_text);
        Button continueButton = view.findViewById(R.id.nastavi);
        Button skipButton = view.findViewById(R.id.skip);

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cardId = cardIdEditText.getText().toString().trim();
                if (cardId.equals("1234")) {
                    navigateToCardStatusFragment();
                } else {
                    showToast("Error: Invalid card ID");
                }
            }
        });

        skipButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToCardStatusFragment();
            }
        });

        return view;
    }

    private void navigateToCardStatusFragment() {
        NavController navController = NavHostFragment.findNavController(this);
        navController.navigate(R.id.action_welcomeFragment_to_cardStatusFragment);
    }

    private void showToast(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }
}