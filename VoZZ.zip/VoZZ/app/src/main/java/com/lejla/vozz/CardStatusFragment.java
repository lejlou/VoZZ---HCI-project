package com.lejla.vozz;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Locale;
import java.util.Random;

public class CardStatusFragment extends Fragment {

    private EditText cardStatusTextView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_card_status, container, false);

        cardStatusTextView = view.findViewById(R.id.card_status);
        Button continueButton = view.findViewById(R.id.nastavi);

        // Generate a random number between 1 and 30
        int randomNumber = new Random().nextInt(30) + 1;

        // Format the number and set it as the card status text
        String cardStatusText = String.format(Locale.getDefault(), "%d BAM", randomNumber);
        cardStatusTextView.setText(cardStatusText);

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToMapFragment();
            }
        });

        return view;
    }

    private void navigateToMapFragment() {
        NavController navController = NavHostFragment.findNavController(this);
        navController.navigate(R.id.action_cardStatusFragment_to_mapFragment);
    }
}