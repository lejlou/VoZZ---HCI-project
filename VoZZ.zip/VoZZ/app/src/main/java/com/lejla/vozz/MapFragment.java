package com.lejla.vozz;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MapFragment extends Fragment {

    private EditText startEditText;
    private EditText endEditText;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_map, container, false);

        startEditText = view.findViewById(R.id.start);
        endEditText = view.findViewById(R.id.end);

        Button allRoutesButton = view.findViewById(R.id.all_routes_btn);
        Button startButton = view.findViewById(R.id.start_btn);

        allRoutesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToAllRoutesFragment();
            }
        });

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isEditTextEmpty(startEditText) || isEditTextEmpty(endEditText)) {
                    Toast.makeText(getContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    navigateToCardStatusFragment();
                }
            }
        });

        return view;
    }

    private boolean isEditTextEmpty(EditText editText) {
        return editText.getText().toString().trim().isEmpty();
    }

    private void navigateToAllRoutesFragment() {
        NavController navController = NavHostFragment.findNavController(this);
        navController.navigate(R.id.action_mapFragment_to_allRoutesFragment);
    }

    private void navigateToCardStatusFragment() {
        NavController navController = NavHostFragment.findNavController(this);
        navController.navigate(R.id.action_mapFragment_to_allRoutesFragment);
    }
}