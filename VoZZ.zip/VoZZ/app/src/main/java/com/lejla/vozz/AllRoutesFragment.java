package com.lejla.vozz;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.lejla.vozz.model.Route;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class AllRoutesFragment extends Fragment {

    private RecyclerView recyclerView;
    private RouteAdapter RouteAdapter;
    private List<Route> routeList;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_all_routes, container, false);

        recyclerView = view.findViewById(R.id.recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        routeList = new ArrayList<>();
        loadRoutesFromJson();

        RouteAdapter = new RouteAdapter(routeList);
        recyclerView.setAdapter(RouteAdapter);

        View menuButton = view.findViewById(R.id.menu);
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToNewsFragment();
            }
        });

        return view;
    }

    private void loadRoutesFromJson() {
        try {
            InputStream inputStream = getActivity().getAssets().open("routes.json");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();

            String json = new String(buffer, "UTF-8");

            JSONArray jsonArray = new JSONArray(json);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String start = jsonObject.getString("start");
                String end = jsonObject.getString("end");

                Route route = new Route(start,end);
                routeList.add(route);
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
    }

    private class RouteAdapter extends RecyclerView.Adapter<RouteAdapter.RouteViewHolder> {

        private List<Route> routes;

        public RouteAdapter(List<Route> routes) {
            this.routes = routes;
        }

        @NonNull
        @Override
        public RouteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.route_item, parent, false);
            return new RouteViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull RouteViewHolder holder, int position) {
            Route route = routes.get(position);
            holder.bind(route);
        }

        @Override
        public int getItemCount() {
            return routes.size();
        }

        class RouteViewHolder extends RecyclerView.ViewHolder {

            private TextView pocetak;
            private TextView kraj;

            public RouteViewHolder(@NonNull View itemView) {
                super(itemView);

                pocetak = itemView.findViewById(R.id.pocetak_rute);
                kraj = itemView.findViewById(R.id.kraj_rute);
            }

            public void bind(Route route) {
                pocetak.setText(route.getStart());
                kraj.setText(route.getEnd());


                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Route selectedRoute = routes.get(getAdapterPosition());
                        navigatetoDetails(selectedRoute);
                    }
                });
            }
        }
    }

    private void navigatetoDetails(Route route) {
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("RoutesPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("start", route.getStart());
        editor.putString("end", route.getEnd());
        editor.apply();

        NavController navController = NavHostFragment.findNavController(this);
        navController.navigate(R.id.action_allRoutesFragment_to_routeDetailsFragment);
    }

    private void navigateToNewsFragment() {
        NavController navController = NavHostFragment.findNavController(this);
        navController.navigate(R.id.action_allRoutesFragment_to_newsFragment);
    }
}